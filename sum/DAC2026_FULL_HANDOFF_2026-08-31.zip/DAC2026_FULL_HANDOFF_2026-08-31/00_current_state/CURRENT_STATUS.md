# Current Status

## Competition state

- Competition: DAC 2026 Preliminary Round, Integrated Claim Risk and Audit Allocation System.
- Current official leaderboard metric: **NormalizedRecall@5% only**.
- Public/private split: **30% / 70%**.
- Maximum submissions: **5 per team per day**.
- Up to **2 final submissions** can be selected for private evaluation.
- External data is now **strictly prohibited**.
- Final notebook/code must reproduce the submitted predictions from official competition data.
- Latest top-1 score reported in chat: **0.97833**.

## Current model status

- **Best observed leaderboard model:** V3, score **0.97166** on the earlier leaderboard. Treat this as the empirical champion architecture. It has not been explicitly confirmed in this handoff that V3 was re-submitted to the reset leaderboard.
- **Best offline model:** V5, OOF NR@5 **0.981019**, 7,856 frauds in 8,008 train audit slots, but reset Public LB only **0.96666**.
- V4 reset LB: **0.96000**. User also reported V4 gives 0.96000 on the old competition, supporting that the files/evaluation population are effectively the same for this submission.
- V2 old Public LB: **0.96333**.
- V1 old Public LB: **0.95833**.

## Current interpretation

The main problem is no longer finding a model that wins OOF. V5 did that convincingly, including 10/10 meta/refiner fold wins, yet did not beat V3 on hidden public labels. The remaining problem is **OOF-to-hidden top-K transfer**, especially around the exact 5% boundary and the difference between cross-fitted/fold-bagged inference versus V3's one-shot full-data boundary refit.

## What we are doing next

Do **not** continue V4 or add more V5 complexity. Build V6 as a controlled deployment experiment around V3:

1. freeze V3 features, base roster, stacker, and 10% hard-risk candidate concept;
2. vary only final test-refiner inference strategy;
3. compare full-data refit, fold probability average, fold rank average, and bagged full-data refits;
4. validate with train-only OOF diagnostics and stability, but acknowledge that the decisive hidden evidence so far favors V3's full-data refiner;
5. do not use the 50/50 positional trick or leaderboard row probing.

## Strategic priority

The competition is likely more report/analysis-heavy than pure Kaggle. The Technical Meeting scoring shared earlier assigns only **10%** to leaderboard and far more to analytical chapters. Therefore a reproducible model around 0.97+ plus a strong, defensible answer sheet can be strategically superior to a suspicious 1.00000 artifact.
