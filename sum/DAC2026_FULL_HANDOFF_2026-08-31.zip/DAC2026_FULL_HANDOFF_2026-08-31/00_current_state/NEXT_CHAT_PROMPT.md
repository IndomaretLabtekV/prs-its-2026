# Suggested Prompt for the Next Chat

Read this entire extracted handoff package before proposing new experiments. The official reset DAC 2026 train/test/sample files were verified byte-identical to the original competition files. V1–V5 have already been explored. Do not restart basic EDA, repeat broad model shopping, or use external data/hidden-label tricks.

Current evidence: V3 is the best observed leaderboard architecture (0.97166 on the earlier leaderboard) with OOF NR@5 0.977522 and 7,828/8,008 TP; V5 is the best offline model (OOF 0.981019, 7,856 TP, 10/10 refiner fold wins) but scored only 0.96666 on reset Public LB. V4 scored 0.96000. This shows OOF improvements are not transferring monotonically.

Continue from `07_next_model/V6_BLUEPRINT.md`. Freeze V3's architecture and investigate only the final deployment/refiner inference strategy first. The main hypothesis is that V3's one full-data hard-negative refiner may transfer better than V5's 10-component fold-bagged rank averaging because it learns from all rare hard negatives. Test that hypothesis in a controlled way before changing features/objectives.

Competition integrity is strict: official train/test/sample only, no external data or pretrained external tabular weights, no claim_id feature, no source row position, no hidden-label reconstruction, no leaderboard row probing, and do not use the rumored 50/50 positional shortcut. Heavy experiments should run on Kaggle T4 x2.
