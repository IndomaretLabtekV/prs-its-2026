# Open Decisions and Next Actions

## Highest-priority unresolved question

**Why does V3 transfer better to hidden public labels than V5 despite weaker OOF?**

The strongest current hypothesis is that V3's final boundary model was retrained on **all high-risk training candidates**, while V5 averages many refiner models each trained on only a subset of the data. For a top-5% problem where the negative class inside the candidate pool is small, full-data boundary training may preserve rare hard-negative patterns that fold bagging smooths away. This is plausible, not proven.

## V6 experiments, in order

1. Reproduce V3 exactly as a control on current official files.
2. Keep all V3 OOF architecture fixed and compare test inference only:
   - original V3 one full-data refiner;
   - 5-fold probability-average refiners;
   - 5-fold rank-average refiners;
   - several full-data refiner seeds averaged in probability space;
   - several full-data refiner seeds rank-averaged.
3. Measure top-5%, top-600, and top-2002 portfolio overlap among these recipes before any submission.
4. Prefer recipes that preserve V3's ranking core instead of churning hundreds of test claims without strong train evidence.
5. Only after the deployment question is resolved should new objectives such as pairwise/pAUC hard-negative loss be considered.

## What not to do next

- Do not expand V4 local empirical-risk direct reranking.
- Do not submit many CatBoost seed/weight variants.
- Do not optimize row positions or use the 50/50 trick.
- Do not use leaderboard movement to infer individual test labels.
- Do not add pretrained tabular foundation models under the external-data ban.
- Do not assume higher OOF automatically implies higher Public/Private LB.

## Paper work that can proceed in parallel

The EDA, leakage discussion, feature engineering rationale, grouped-validation design, 3/5/7% capacity analysis, fairness, explainability, location-transport risk, governance, and human-review workflow are already strong enough to draft. The final report should use the final selected model's executed numbers, but most analytical structure is stable.
