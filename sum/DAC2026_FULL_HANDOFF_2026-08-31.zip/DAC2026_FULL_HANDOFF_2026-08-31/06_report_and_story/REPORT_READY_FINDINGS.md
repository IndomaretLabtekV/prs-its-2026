# Report-Ready Findings Already Supported

These findings are stable enough to draft now, although final model numbers should be refreshed from the chosen final notebook.

## Data quality / leakage

- No raw missing cells.
- No duplicate claim IDs.
- No exact duplicate rows.
- Strong storage-order artifact: positive labels are stored contiguously before negatives.
- Stable source-order tie breaking can create invalidly strong baselines; pipeline explicitly neutralizes this.
- Repeated feature signatures exist and some have conflicting labels; grouped CV is therefore justified.
- Administrative codes must remain categorical strings because leading zeros are meaningful to identity even if the numeric digits are anonymized.

## Predictive structure

- Geography/administrative codes and facility interactions carry the strongest observed signal.
- Diagnosis/service/CMG interactions and burden-density/concentration features are useful around the audit boundary.
- Strong signal is association, not proof of fraud causality.

## Validation

- Exact-signature grouped 5-fold CV is the primary feasible validation view.
- Ordinary stratification is optimistic because repeated signatures can cross folds.
- Location-held-out validation is a separate transport stress test and should not replace primary CV.

## Audit allocation

For the V2 anchor at 5%, only 236 of 8,008 selected train claims were legitimate; later boundary models reduced this further offline. Capacity analysis must report 3%, 5%, and 7%.

## Fairness

V2 at 5% had extremely small legitimate-audit FPR gaps:

- gender gap ~0.000106;
- age gap ~0.001153;
- Protection ~0.998847.

Removing protected attributes did not automatically improve fairness, illustrating that proxy/case-mix information remains.

## Explainability

Global importance repeatedly emphasized geography/facility, diagnosis-service, diagnosis-CMG, severity interactions, age, and diagnosis. SHAP/native importance must be presented as predictive attribution, not causal evidence.

## Robustness

Unseen-location stress is much worse than in-distribution grouped OOF. The model should be validated/shadowed before deployment to new geographic/provider regimes.

## Governance

The model prioritizes **human investigation only**. It must not auto-reject claims. Override, appeal, monitoring, randomized audits, label maturity, drift checks, versioning, and retraining/recalibration policy should be part of the recommended process.
