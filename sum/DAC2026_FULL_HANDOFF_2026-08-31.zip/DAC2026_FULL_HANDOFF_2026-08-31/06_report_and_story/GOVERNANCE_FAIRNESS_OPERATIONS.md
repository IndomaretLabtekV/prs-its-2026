# Governance, Fairness, and Operational Recommendation

## Investigator interface

Show:

- fraud probability/risk score;
- audit rank and current capacity boundary;
- source claim facts;
- top signed model drivers;
- data-quality/rarity warnings;
- comparable pattern context;
- uncertainty/support indicators where available;
- explicit override/escalation/appeal route.

Avoid accusatory wording such as “fraudulent claim.” Use “high-risk claim requiring review.”

## Human override

Allow override when there is documented evidence of severe data error, urgent patient-harm concern, credible contradictory documentation, or a novel pattern outside model representation. Log override reason and downstream adjudication.

## Appeal and escalation

The score cannot be the sole adverse-action basis. Disputed cases should have senior/independent review and a clear correction/appeal mechanism.

## Feedback-loop protection

If only model-selected high-risk claims are audited, future labels become selection-biased. Maintain a small randomized audit stream and label-maturity metadata to estimate population performance and detect new fraud types.

## Monitoring dashboard

Track:

- NR@3/5/7 and precision in audit portfolio;
- AP and Brier/calibration slope/intercept;
- gender/age legitimate-audit FPR gaps with denominators;
- input schema, missingness, unseen categories, leading-zero preservation;
- feature distribution drift and adversarial AUC;
- score distribution and top-boundary churn;
- performance by location/service/provider type;
- override, appeal, delay, and investigator outcomes;
- label maturity/adjudicator agreement;
- explanation/feature-importance drift;
- model version, failures, rollback readiness.

## Recalibration / retraining

Recalibrate only when mature representative labels show probability reliability deterioration. Retrain when ranking loss, concept drift, data-contract change, new fraud typology, or transport failure is sustained and verified.
