# Answer Sheet / Report Blueprint

## Required high-level structure

Keep the official/previous-winning style:

1. **CHAPTER I: Introduction**
2. **CHAPTER II: Theoretical Framework**
3. **CHAPTER III: Analytical Steps**
4. **CHAPTER IV: Analysis of Results**
5. **CHAPTER V: Conclusion and Recommendation**
6. **REFERENCES**
7. **ATTACHMENT**

The 2025 winning answer sheet was used only as a structural/presentation reference, not as a method authority. Its useful pattern was: problem/RQs → theory → analytical flow → comparative results → statistical interpretation → conclusion/recommendation → references/attachments.

## Technical Meeting scoring weights previously extracted

Preliminary-round scoring shared in the TM material:

- Chapter I: **5%**
- Chapter II: **20%**
- Chapter III: **15%**
- Chapter IV: **35%**
- Chapter V: **10%**
- Leaderboard: **10%**
- Writing: **5%**

This is why the strategy should not sacrifice analytical defensibility for a suspicious 1.00000 leaderboard artifact.

## Suggested research questions for DAC 2026

- RQ1: What data-quality, leakage, proxy, and dependency structures affect valid fraud-risk modeling?
- RQ2: Which reproducible model best prioritizes fraud under the 5% audit constraint, and how robust is it across 3/5/7% budgets?
- RQ3: Which claim/provider/clinical patterns drive risk predictions, and what are their limitations as non-causal associations?
- RQ4: Does audit prioritization create differential legitimate-audit exposure by gender or age?
- RQ5: How should NHPA integrate the model into human review, monitoring, appeal, and retraining processes?

## Chapter III analytical flow

Raw official data → data contract & EDA → leakage/duplicate/template forensics → grouped validation → feature engineering → progressive model ladder → rank-first stack/refiner → calibration/report-only reliability → 3/5/7 audit allocation → fairness → explainability → robustness/transport → operational recommendation.

## Chapter IV emphasis

Do not write a chronological experiment diary. Present only decision-relevant evidence:

- why row-order leakage is dangerous;
- why grouped CV is needed;
- why CatBoost is the anchor;
- what V3/V6 adds at the audit boundary;
- how many frauds/legitimate claims are selected at 3/5/7%;
- fairness gaps and uncertainty;
- feature drivers and non-causal caveats;
- location transport weakness;
- final model limitations and monitoring.
