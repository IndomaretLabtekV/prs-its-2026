# Validation vs Leaderboard Transfer

## Observed pattern

Approximate OOF-to-public gaps:

- V2: 0.97053 OOF → 0.96333 Public, gap ~-0.0072.
- V3: 0.97752 OOF → 0.97166 Public, gap ~-0.00586.
- V4: 0.97340 OOF → 0.96000 Public, gap ~-0.01340.
- V5: 0.98102 OOF → 0.96666 Public, gap ~-0.01436.

V3 had the smallest known gap among the advanced versions.

## Why the gap can exist

1. Public labels are only a subset of hidden evaluation labels.
2. Top-K is discontinuous: swapping a few rows around K changes the score materially.
3. Model-selection overfit can occur even with grouped OOF, especially after searching candidate rates, weights, meta models, and refiners.
4. Fold partitions differ across versions, so OOF comparisons are not perfectly matched.
5. Test inference can differ structurally from OOF inference.
6. Rare hard-negative patterns may be poorly represented in each fold-specific boundary model.

## What this does NOT justify

- It does not justify inferring individual hidden labels from leaderboard changes.
- It does not justify manual test-row editing.
- It does not prove Public/Private label distributions differ materially.

## New selection philosophy

- Use OOF to reject clearly bad ideas.
- Require repeatable directional evidence.
- But for deployment variants, preserve the known V3 ranking core unless the offline evidence is very strong.
- Avoid large test portfolio churn from small OOF gains.
- Treat Public LB only as a coarse external signal, never a row oracle.
