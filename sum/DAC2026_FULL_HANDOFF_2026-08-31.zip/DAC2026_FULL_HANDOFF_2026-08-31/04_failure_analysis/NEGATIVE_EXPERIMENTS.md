# Negative / Inconclusive Experiments

## Clearly negative or misleading

- Source-order constant/prevalence baseline.
- Burden baseline “perfect” top-3% under source-order ties.
- Isotonic calibration for exact top-K.
- V1 arbitrary ordinal category encoding for XGB.
- Removing location features: large performance loss.
- Removing protected variables as a fairness shortcut: did not improve Protection.
- V4 direct empirical-risk rank adjustment.
- V4 conservative fixed consensus as a replacement for V3 learned stacker.
- V5 10-component bagged deployment as an assumption of guaranteed generalization.

## Inconclusive

- Two-seed CatBoost mean: tiny gains, not enough evidence.
- Code-prefix hierarchy: semantically questionable, small isolated contribution.
- Burden-density family by itself: plausible but weak isolated evidence.
- Whether fold-average is universally superior to full refit on hidden labels: now explicitly doubtful.
- Simple V3/V5 rank blend: offline only about +7 TP over V5, too small to justify another submission without stronger evidence.

## Deliberately not pursued yet

- Massive Optuna search.
- Deep tabular network as core model.
- Pairwise/pAUC objective as V5 core.
- Pretrained tabular foundation models under reset rules.

Reason: each adds search/complexity before the deployment discrepancy is understood.
