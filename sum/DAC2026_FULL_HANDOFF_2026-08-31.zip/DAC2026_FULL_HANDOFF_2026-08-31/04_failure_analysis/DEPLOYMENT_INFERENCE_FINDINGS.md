# Deployment / Inference Findings

## V1

Full-data refit versus fold-average CatBoost test predictions had ~0.994 correlation but only ~91.66% top-5 overlap. This established that exact audit portfolios can change materially even when global score vectors look almost identical.

## V3

- Base/stack OOF were cross-fitted.
- Boundary OOF was cross-fitted.
- Final test refiner was retrained once on **all high-risk training candidates**.

This was originally flagged as validation/deployment mismatch.

## V5

V5 tried to fix the mismatch:

- two meta seeds;
- five folds each;
- complete refiner test predictions from each held-out recipe;
- 10 components converted to percentile ranks and averaged.

Offline evidence became stronger, but hidden Public LB worsened.

## Current hypothesis

For this specific boundary problem, the one full-data refiner may be useful because the candidate region is already ~90–95% fraud and the legitimate hard negatives are relatively rare. A fold-specific refiner sees fewer of those hard negatives. Averaging many such models may smooth the exact discriminative patterns needed around the 5% cutoff.

This hypothesis is **plausible but unproven**. It is the primary V6 research question.

## Controlled variants to test

- Full-data refiner, one seed: V3 control.
- Full-data refiners, several seeds, probability mean.
- Full-data refiners, several seeds, rank mean.
- 5-fold refiner probability mean.
- 5-fold refiner rank mean.
- Optional hybrid: full-data refiner as dominant score with small fold-bag stabilizer.

Do not simultaneously change base features, candidate definition, and objective while testing this.
