# What Failed and Why

## 1. Source-order tie breaking

**Failure:** stable sorting of tied scores preserved train row order, which was label-blocked.  
**Effect:** trivial/constant baselines looked nearly perfect.  
**Fix:** deterministic label-neutral tie key; never source index.

## 2. Fold-specific calibration used as a global ranking object

**Failure:** different sigmoid maps were fitted on different folds, then concatenated.  
**Effect:** globally reordered OOF rows and lost top-K fraud despite each map being monotone within a fold.  
**Fix:** calculate ranking on a common raw score; evaluate calibration separately; final monotone map only after ranking is locked.

## 3. Isotonic calibration

**Failure:** generated broad probability plateaus.  
**Effect:** exact-K boundary became tie-sensitive; V2 isotonic had a boundary tie around 896 rows.  
**Decision:** diagnostic only, not final ranking method.

## 4. V1 blend/deployment mismatch

**Failure:** OOF blend could use fold-varying weights while deployment used one median weight.  
**Fix:** same fixed formula in validation and test.

## 5. Arbitrary ordinal categorical encoding in XGBoost

**Failure:** category integers were treated as ordered numerical split values.  
**Fix:** one-hot/sparse for XGB/LGBM, native cats for CatBoost.

## 6. Over-trusting small OOF gains

V4 selected a CatBoost mean with only ~+11 TP OOF over Cat A. Hidden Public LB fell to 0.96000. Small top-K gains do not justify large portfolio churn without stronger evidence.

## 7. Direct empirical-risk reranking

V4's hierarchical local-risk layer was sophisticated, but using it directly as a rank adjustment consistently lost ~8–22 OOF TP. Empirical risk should be **supporting evidence to a supervised model**, not a deterministic second ranking.

## 8. Assuming deployment-aligned fold bagging must generalize better

V5 repaired V3's validation/test mismatch and won 10/10 held-out refiner folds, yet Public LB was 0.96666 versus V3's 0.97166 benchmark. Clean methodology does not guarantee the best hidden top-K ranking when each fold refiner loses access to some rare hard negatives.

## 9. Assuming OOF monotonicity across versions

V5 OOF > V3 OOF > V4 OOF, but hidden public order was V3 > V5 > V4. The project must now treat OOF as a noisy proxy for exact hidden boundary ranking, especially after model-selection layers.

## 10. Broad architecture changes after a known strong branch

V4 changed several things at once: removed stacker, changed CatBoost consensus, changed local-risk use, changed inference. That made diagnosis harder. V6 should change **one deployment variable at a time** around V3.
