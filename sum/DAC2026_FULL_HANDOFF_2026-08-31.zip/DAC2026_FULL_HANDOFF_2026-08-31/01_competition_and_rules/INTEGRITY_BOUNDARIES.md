# Competition Integrity Boundaries

## Strictly allowed

- Official `train.csv`, `test.csv`, `sample_submission.csv`.
- Features derived from those official columns.
- Train-only target statistics when constructed fold-safely.
- Academic papers and public methodology references for theoretical justification.
- Standard software libraries and algorithms.

## Strictly prohibited by reset rules

- External datasets related to competition records or target labels.
- Exact or approximate matching to external labeled datasets.
- Public/leaked hidden labels, predictions, or evaluation outcomes used to infer rows.
- Recovering hidden test labels from external sources.
- Sharing/obtaining unfair competition information from other teams.
- Manual encoding of hidden evaluation or leaderboard outcomes.
- Claim ID as predictive signal.

## Project-specific helper files

Two helper files existed in earlier analysis:

- `ground_truth.csv`: 40,043 test claim IDs, **zero available test labels**, status indicating hidden label unavailable.
- `ground_truth_train_reference.csv`: exact train IDs and known train labels, matching official train data.

They contain no hidden-test information. They may be used by the analyst for sanity/documentation, but **must not be read by the final competition notebook**. V3+ notebooks intentionally excluded paths containing `ground_truth`.

## The 50/50 positional trick

The user was told that a 1.00000 score could allegedly be obtained by assigning scores according to row halves. A provided positional submission file itself had 20,022 first rows at one value and 20,021 last rows at the other, while the verbal description discussed the reverse ordering. This is not reliable evidence of the hidden test labels and, more importantly, using such information as a prediction rule would conflict with the reset rule against manually encoding hidden evaluation information.

Treat this only as evidence that **storage/order artifacts are a competition-integrity risk**. It should be discussed in the leakage section of the report and explicitly neutralized, not exploited.
