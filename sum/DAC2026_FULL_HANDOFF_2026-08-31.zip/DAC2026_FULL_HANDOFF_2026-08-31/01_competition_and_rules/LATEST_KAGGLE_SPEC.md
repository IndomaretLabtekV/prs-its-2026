# Latest Kaggle Specification and Reset Changes

## Problem

Build an **Integrated Claim Risk and Audit Allocation System**. Each test claim receives `fraud_probability` in [0,1]. Claims are ranked descending and only the top 5% are placed in the official audit portfolio.

For N evaluation claims:

`K = floor(0.05 * N)`

`Recall@5% = TP_K / P`

`Recall_max = min(1, K/P)`

`NormalizedRecall@5% = Recall@5% / Recall_max`

For the provided test size N=40,043, full-test K is **2,002**.

## Main analytical tasks

- **Task A:** data quality, duplicates, unusual values, high cardinality, proxies, leakage, subgroup patterns, association-vs-causality.
- **Task B:** fraud-risk model, feature prep, encoding, model choice, validation, imbalance, leakage/overfit prevention, calibration, prediction drivers.
- **Task C:** audit allocation, fraud capture, legitimate audits, baselines, and robustness at 3%, 5%, 7% capacity.
- **Task D:** policyholder protection by gender and age 0–17, 18–39, 40–59, 60+; careful disparity interpretation.
- **Task E:** operational decision process, human override, escalation/appeal, monitoring, drift, retraining, decision-support boundary.

## Reset changes announced by organizers

1. **External data is no longer allowed.**
2. Leaderboard was reset and a new Kaggle competition link issued.
3. Final notebook/code must reproduce the submitted predictions.
4. Daily submission limit increased from 3 to **5**.
5. A more complete data dictionary was published.

## Leaderboard structure

- Public: 30%.
- Private: 70%.
- Up to 2 final submissions selected for private evaluation.

## Required deliverables

1. CSV with `claim_id,fraud_probability`.
2. Analytical report, max 20 pages excluding appendix.
3. Reproducible notebook/code package using only official data.
4. Concise software/library/compute description.

## Data dictionary notes relevant to modeling

- `kdkc`, `dati2`: anonymized categorical administrative/geographic codes, not continuous quantities.
- `typeppk`: facility/provider category.
- `jkpst`: gender category.
- `umur`: age.
- `jnspelsep`: service type.
- `los`: length of stay.
- `cmg`: case-mix group.
- `severitylevel`: ordinal 0–3.
- `diagprimer`: primary diagnosis group.
- `dx2_*`, `proc*`: non-negative counts.
- `claim_id`: observation identifier only, never predictive.

The published dictionary contains wording inconsistencies versus the raw CSV: it describes `claim_id` as integer and `label` as a continuous fraud probability, while the actual competition train file observed in this project uses claim-like IDs and binary 0/1 labels. Raw data is treated as empirical truth for implementation.
