# V6 Minimal Experiment Matrix

| ID | Fixed architecture | Test refiner training | Test aggregation | Primary question |
|---|---|---|---|---|
| V6-A | V3 | 100% candidate rows, seed 2026 | single probability | Exact V3-style control |
| V6-B | V3 | 5 fold subsets | probability mean | Does standard bagging help? |
| V6-C | V3 | 5 fold subsets | rank mean | Does scale-free bagging help? |
| V6-D | V3 | 100% candidate rows, 3–5 seeds | probability mean | Preserve full hard negatives while reducing seed variance |
| V6-E | V3 | 100% candidate rows, 3–5 seeds | rank mean | Same, scale-free |
| V6-F optional | V3 | full + folds | weighted hybrid | Only if A–E show complementary evidence |

## Gates

- First gate: reproduce V3 control ranking closely.
- Second gate: deployment variants should not create unjustified large top-600/top-2002 churn.
- Third gate: any new submission should have a clear mechanistic reason and offline stability, not merely a few extra OOF TP.
- Fourth gate: remain 100% reproducible from official data.

## If none beats V3 convincingly

Stop Kaggle tuning. Use V3/V6-A as the technical model and shift effort to the report, which has far more scoring weight than leaderboard.
