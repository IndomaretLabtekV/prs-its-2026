# Stop / Do Not Repeat List

Do not repeat unless new evidence directly justifies it:

- basic train/test EDA already established;
- searching for hidden ground truth;
- external-data matching;
- source-row-order features/tie breaking;
- 50/50 positional submission trick;
- XGB ordinal categories;
- isotonic final calibration;
- protected-attribute removal as a fairness “fix”;
- location removal as a default;
- V4 fixed consensus/direct local-risk reranking;
- V5-style assumption that more fold bagging is automatically better;
- broad Optuna/model zoo search;
- dozens of near-identical seed/weight submissions;
- public-LB row probing;
- manual probability edits after leaderboard feedback.

If Kaggle improvement remains marginal after V6, the expected-value move is to finish the report rather than continue model churn.
