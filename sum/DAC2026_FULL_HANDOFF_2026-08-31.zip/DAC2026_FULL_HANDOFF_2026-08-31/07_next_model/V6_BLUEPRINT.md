# V6 Blueprint — Freeze V3, Isolate Deployment

## Core decision

**Do not build V6 as a new model family.** V6 is a controlled experiment around V3's final inference.

## Fixed components

Keep exactly or as close as possible to V3:

- same official data only;
- same cleaning and semantic categoricals;
- same exact-signature grouped folds;
- same feature package;
- same base model roster;
- same cross-fitted logistic stacker;
- same supervised CatBoost refiner concept;
- candidate region centered around the proven ~10% high-risk pool;
- same NR@5-first objective;
- no external data, claim ID feature, or row position.

## Variable under test: refiner deployment only

### A. V3 control

Train one final refiner on **all** high-risk OOF training candidates and predict the test high-risk candidate pool.

### B. Five-fold probability bag

Five refiners trained on fold training candidate subsets; average probabilities.

### C. Five-fold rank bag

Same refiners; convert each test vector to percentile rank and average ranks.

### D. Full-data multi-seed probability ensemble

Train several refiners on **100% candidate data**, only seed differs; average probabilities.

### E. Full-data multi-seed rank ensemble

Same full-data seeds; rank-average.

### Optional F. Hybrid

Dominant full-data refiner plus a small stabilizing contribution from fold-bag score. Only test after A–E.

## Why this experiment

V3 hidden public > V5 hidden public even though V5 had stronger OOF and 10/10 fold wins. The biggest structural difference at deployment is V3's all-candidate final refit versus V5's many partial-data refiners. V6 tests that hypothesis directly.

## Selection evidence

Before submission, record:

- train OOF NR@3/5/7 where meaningful;
- test top-600 and top-2002 overlap versus V3 control;
- rank correlations;
- boundary churn;
- disagreement concentrated near cutoff;
- sensitivity across refiner seeds.

Avoid promoting a variant that swaps hundreds of V3 top claims for only a tiny OOF proxy improvement.

## What V6 should NOT add yet

- New neural tabular model.
- Pairwise ranking loss.
- New large feature family.
- More empirical-risk direct reranking.
- Broad hyperparameter optimization.

Those can become later experiments only if deployment inference fails to explain the gap.
