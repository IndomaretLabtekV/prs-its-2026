# Cross-Version Comparison

| Version | OOF NR@5 | OOF TP@5 | Known Public LB | Main architecture | Current interpretation |
|---|---:|---:|---:|---|---|
| V1 | 0.970155 raw | 7,769 | 0.95833 | CatBoost + calibration/full refit | Strong starting point, several evaluation/deployment flaws |
| V2 | 0.970529 | 7,772 | 0.96333 | Corrected grouped CatBoost fold-average | Clean single-model anchor |
| V3 | **0.977522** | **7,828** | **0.97166** | Stacker + supervised boundary refiner | **Best observed leaderboard architecture** |
| V4 | 0.97340 | 7,795 | 0.96000 | Fixed Cat consensus + direct local-risk rerank | Negative experiment |
| V5 | **0.981019** | **7,856** | 0.96666 | Repaired V3 + EB features + 10-component bagging | **Best OOF, not best hidden public** |

## Important warning

OOF values are not perfectly apples-to-apples across every version because fold partitions/recipes changed. They are useful evidence, not a single shared benchmark table. V5's repeated refiner validation is stronger internally than V3's single meta partition, yet the hidden leaderboard still favored V3.

## Public score arithmetic heuristic

The observed scores strongly resemble fractions of a ~600-slot public audit portfolio:

- 0.95833 ≈ 575/600.
- 0.96333 ≈ 578/600.
- 0.96666 ≈ 580/600.
- 0.97166 ≈ 583/600.
- 0.97833 ≈ 587/600.
- 1.00000 = 600/600.

This is a useful interpretation of score granularity, **not organizer-confirmed internals** and never a basis for row-level leaderboard probing.

## Main empirical conclusion

V3 is currently the best branch to continue because it is the only architecture change that produced a material OOF gain **and** the strongest known hidden-public performance. V4 and V5 provide valuable negative/diagnostic evidence about what not to assume.
