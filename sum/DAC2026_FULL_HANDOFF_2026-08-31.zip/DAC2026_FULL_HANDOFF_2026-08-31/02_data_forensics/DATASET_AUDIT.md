# Dataset Forensics

## Shapes and target

- Train: **160,174 × 53**.
- Test: **40,043 × 52**.
- Sample submission: **40,043 × 2**.
- Training positives/fraud: **80,203**.
- Training negatives/legitimate: **79,971**.
- Training fraud prevalence: **50.0724%**.
- No duplicate train/test claim IDs.
- No train/test claim-ID overlap.
- No raw missing cells.

The ~50/50 class balance is likely a curated competition sample and must not be presented as operational fraud prevalence.

## Critical source-order artifact

The train label sequence has only **one transition**: all 80,203 positive labels appear first, followed by all 79,971 negative labels. Source row order therefore cannot be used as a feature, tie breaker, or any training signal.

This artifact caused early coarse baselines to look absurdly strong when stable source-order sorting broke ties. Example from V1 forensics:

- Constant score 0.5 with source-order tie resolution selected 8,008/8,008 frauds.
- With a neutral tie key, the same constant predictor captured only about 4,032–4,045, close to random expectation ~4,009.8.
- Burden baseline source-order TP 4,821 versus neutral-key ~4,264.

Serious CatBoost predictions had very small boundary ties, so their performance was not explained by this artifact. The artifact contaminated diagnostics/baselines, not the core CatBoost signal.

## Semantic dtypes

Administrative codes must be read as strings from the CSV boundary:

- 46,210 `kdkc` values begin with zero.
- All 160,174 `dati2` values begin with zero.

Allowing integer inference destroys those leading zeros.

## Duplicate/template structure

- Exact duplicate train rows: **0**.
- Repeated exact-feature signature groups: **6,747**.
- Rows inside repeated signatures: **17,906**.
- Repeated signature groups with conflicting labels: **1,737**.
- Exact test rows matching a full train signature: **0**.
- Test rows matching a reduced clinical template: **31,410 / 40,043**.

Implications:

- Exact signatures should be grouped into the same validation fold.
- Conflicting labels prove that repeated patterns are not deterministic fraud rules.
- Large reduced-template overlap motivates train-only local-risk/retrieval features, but never hidden-label reconstruction.

## Unusual values

- Age: 0–109; no invalid <0 or >120 cases.
- LOS: 0–592.
- 10 LOS values exceed 365; treated as review flags, not deletions.
- No negative diagnosis/procedure counts.
- No non-integer grouped count values.
- Constant columns excluded in prior pipelines: `dx2_koo_k93`, `dx2_u00_u99`, `procv00_v89`.

## Train/test shift

- Adversarial validation AUC: **0.5068**, close to chance.
- Largest measured univariate shift around 0.0133 on the project scale.
- Zero unseen semantic categorical levels in test.

Conclusion: measured covariate shift is small; it is not the main demonstrated reason leaderboard transfer is imperfect.
