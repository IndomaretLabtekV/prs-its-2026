# Original vs Reset Kaggle Dataset Comparison

The newly supplied/reset competition archive was compared against the original archive.

## Result

`train.csv`, `test.csv`, and `sample_submission.csv` were **byte-identical**, including row order. SHA-256 comparison matched for each corresponding file during the audit.

Therefore:

- Train remains 160,174 rows.
- Test remains 40,043 rows.
- Feature values are unchanged.
- Labels are unchanged.
- Train label storage order remains the same positive block followed by negative block.
- Test row order remains the same.

The reset changed **competition rules and leaderboard state**, not the actual supplied CSV content observed in this project.

This is why V1–V3 feature/forensic findings remain analytically useful. Old leaderboard scores, however, are historical evidence and should not be treated as current private-ranking guarantees.
