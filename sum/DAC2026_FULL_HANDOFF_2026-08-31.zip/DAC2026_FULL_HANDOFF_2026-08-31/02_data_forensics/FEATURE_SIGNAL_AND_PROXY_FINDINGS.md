# Feature Signal, Error Structure, and Proxy Findings

## Strongest categorical associations observed

Approximate Cramér's V:

- `dati2`: **0.2983**
- `kdkc`: **0.2509**
- `typeppk`: **0.1229**
- `cmg`: **0.1122**
- `severitylevel`: **0.0777**
- `jnspelsep`: **0.0533**
- `diagprimer`: **0.0194**
- `jkpst`: **0.0114**

Strongest numeric rank-biserial effect was LOS at about 0.0757.

Fold-safe single-feature AP was strongest for:

- `dati2`: 0.6546
- `kdkc`: 0.6276
- `typeppk`: 0.5525
- `cmg`: 0.5426
- `severitylevel`: 0.5218
- `los`: 0.5213

## Important engineered families

Useful or repeatedly motivated families included:

- geography × facility;
- diagnosis × service;
- diagnosis × CMG;
- CMG × severity;
- diagnosis × facility;
- CMG × facility;
- burden totals and log burden;
- procedure/diagnosis density per LOS;
- diagnosis/procedure entropy and concentration;
- fold-safe frequency/rarity features;
- hierarchical empirical-risk statistics.

## Error patterns motivating boundary modeling

V1/V2 error analyses showed that false positives and near-boundary missed frauds differed particularly in:

- burden per day;
- procedure per day;
- procedure nonzero groups;
- procedure max share;
- location/facility combinations;
- diagnosis/service and diagnosis/CMG interactions.

This motivated V3's specialized high-risk refiner.

## Location as a proxy/deployment risk

Location/facility signal is predictive but fragile under transport:

- Primary grouped model Technical Score ~0.9211.
- Unseen-`kdkc` stress Technical Score ~0.7308.
- Delta ~**-0.19025**.
- Removing location historically cost ~0.095 Technical Score.

Competition strategy: retain location for in-distribution ranking, but describe it as a governance/proxy risk and monitor performance by geography. Do not interpret feature importance as causal fraud evidence.

## Administrative code prefixes

V2/V3 experimented with code-prefix features. The reset data dictionary says anonymized codes should be treated categorically and does not guarantee digit hierarchy. Prefix contribution was weak/inconclusive in isolated screens. V4 removed prefixes by default. Future work should not rely on them unless a clean ablation shows repeatable gain.
