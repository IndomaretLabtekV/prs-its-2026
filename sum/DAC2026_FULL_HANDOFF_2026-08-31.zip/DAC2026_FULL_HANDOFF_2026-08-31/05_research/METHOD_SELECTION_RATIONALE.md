# Method Selection Rationale

## Why CatBoost stays central

The data combine moderate-size numeric counts with meaningful high-cardinality categoricals and interactions. CatBoost consistently dominated the single-model ladder and handles categories without imposing arbitrary numerical order.

## Why keep XGBoost/LightGBM/logistic despite lower standalone scores

They provide different errors/ranking views. V1/V2 measured materially lower top-5 overlap between CatBoost and other families. In V3, a supervised stacker extracted value from this disagreement.

## Why no SMOTE / class weighting

Training labels are already ~50/50. The operational population may not be, but the competition train sample does not justify synthetic imbalance treatment.

## Why grouped CV

Repeated exact-feature signatures exist and some have conflicting labels. Ordinary stratification would allow the same signature pattern across folds. Grouping exact cleaned signatures is a defensible minimum leakage control.

## Why a boundary specialist

Only 5% of claims matter to the official metric. Global logloss models spend most capacity on ranking/calibration outside this operational region. V3 proved that a second model trained on the top ~10% can reduce high-risk false positives materially.

## Why simple logistic stacker

The base predictions are already strong nonlinear representations. A simple regularized meta model reduces the chance of another highly flexible layer memorizing OOF noise.

## Why empirical-risk features are not direct decisions

V4 directly reranked with local-risk estimates and consistently lost TP. V5 showed they can contribute inside a supervised refiner, but their net hidden value is still uncertain. Use local rates, support, purity, entropy, and Wilson uncertainty as evidence, not deterministic fraud rules.

## Why V6 should not change the objective yet

V3 works. V5 shows the major unresolved issue is deployment transfer. Changing to pairwise/pAUC loss before resolving inference would confound the experiment. First isolate deployment. Then, if still needed, test ranking-specific loss in a separate version.
