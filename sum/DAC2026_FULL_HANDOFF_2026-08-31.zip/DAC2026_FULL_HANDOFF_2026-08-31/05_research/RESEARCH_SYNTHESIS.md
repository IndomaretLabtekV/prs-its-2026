# Research Synthesis Used in the Project

## Established literature used for the main solution

### Gradient boosting for mixed tabular claims

- Friedman: gradient boosting foundation.
- CatBoost: ordered boosting/native categorical processing; best empirical anchor in this dataset.
- XGBoost and LightGBM: complementary tree families that provide useful disagreement even when standalone scores are lower.

### Structured validation and leakage

- Kaufman et al.: leakage formulation/detection/avoidance.
- Roberts et al.: CV for structured/hierarchical dependence.
- Cawley & Talbot: model-selection overfitting and selection bias.

These support exact-signature grouping, strict fold-safe statistics, and conservative interpretation of repeated experiment screens.

### Precision-recall / limited-audit evaluation

- Davis & Goadrich.
- Saito & Rehmsmeier.
- Kar, Narasimhan & Jain (2015), precision-at-the-top surrogates.

The competition's metric is effectively an extreme-tail ranking objective. This motivated V3's rank-first architecture and boundary specialist.

### Partial-AUC / hard-negative ideas

Research discussed in the chat included partial-AUC structural optimization and later CVaR/DRO-style hard-negative optimization. These are conceptually aligned with “separate a few high-scoring legitimate claims from many high-scoring frauds.” They remain a **future V6/V7 option**, not yet core, because standard CatBoost boundary refinement already worked and the deployment discrepancy must be isolated first.

### Calibration

- Brier score.
- Niculescu-Mizil & Caruana.
- Kull et al. beta calibration.
- Van Calster et al. calibration reliability.

Project finding: raw CatBoost was already well calibrated on the curated train sample; complex calibration should not be allowed to damage ranking.

### Explainability, fairness, and governance

- SHAP/Lundberg & Lee, with caveats from Kumar et al.
- Hardt et al. and Rajkomar et al. for differential error/fairness framing.
- WHO AI ethics and health-financing/fraud reports.
- NIST AI RMF.
- Kelly et al. on clinical AI deployment.
- Gama et al. on concept drift.

These support decision-support framing, non-causal explanations, human override, appeal, drift monitoring, randomized audits, and subgroup exposure analysis.

## Modern tabular research discussed after V3

### TabR / retrieval-augmented tabular learning

Relevant because 31,410/40,043 test rows match reduced train clinical templates. The idea influenced train-only local empirical-risk/retrieval features. Full neural retrieval was not adopted because V4 showed that direct local-risk ranking can hurt, and the external-data rule makes pretrained approaches harder to defend.

### ModernNCA

Discussed as evidence that learned neighborhood structure can be competitive on tabular data. Not implemented.

### TabM

Discussed as a strong parameter-efficient neural tabular architecture. If ever tested, it should be trained **from scratch** on official competition data. It was not promoted because tree models already perform strongly and architecture risk is higher than the current deployment problem.

### TabPFN / TabDPT-style pretrained foundation models

Not recommended under the reset rules because pretrained weights encode knowledge learned from external datasets. Even if technically permitted by some competitions, this competition explicitly says all modeling decisions/features should derive from official data, so using external pretrained tabular weights is unnecessarily risky.

## Research conclusion

The strongest evidence currently supports:

1. CatBoost as anchor;
2. diverse weaker families as meta disagreement;
3. cross-fitted supervised stacking;
4. supervised high-risk boundary refinement;
5. train-only local/hierarchical statistics as **features**, not deterministic rules;
6. rigorous integrity, grouped validation, and report/governance analysis.
