# Bibliography / Reference Bank

The following references were already gathered or discussed and can be reused in the report. Verify exact access dates/format when finalizing the answer sheet.

1. DAC 2026 Competition Committee, official preliminary-round specification and evaluation rules, 2026.
2. WHO, *Use of Machine Learning for Fraud Detection within the Claims Management Process in the Philippines: Insights from the National Health Insurance Scheme PhilHealth*, 2024.
3. WHO, *The Implications of Artificial Intelligence and Machine Learning in Health Financing for Achieving Universal Health Coverage*, 2023.
4. A. du Preez et al., “Fraud detection in healthcare claims using machine learning: A systematic review,” *Artificial Intelligence in Medicine*, 2025.
5. H. Joudaki et al., “Using data mining to detect health care fraud and abuse: A review of literature,” *Global Journal of Health Science*, 2015.
6. J. Davis and M. Goadrich, “The relationship between Precision-Recall and ROC curves,” ICML, 2006.
7. T. Saito and M. Rehmsmeier, “The Precision-Recall plot is more informative than the ROC plot...,” PLOS ONE, 2015.
8. G. W. Brier, “Verification of forecasts expressed in terms of probability,” 1950.
9. B. Van Calster et al., “Calibration: The Achilles heel of predictive analytics,” BMC Medicine, 2019.
10. M. Kull, T. M. Silva Filho, and P. Flach, “Beta calibration,” AISTATS, 2017.
11. S. Kaufman et al., “Leakage in data mining: Formulation, detection, and avoidance,” ACM TKDD, 2012.
12. D. R. Roberts et al., “Cross-validation strategies for data with temporal, spatial, hierarchical, or phylogenetic structure,” Ecography, 2017.
13. G. C. Cawley and N. L. C. Talbot, “On over-fitting in model selection...,” JMLR, 2010.
14. J. H. Friedman, “Greedy function approximation: A gradient boosting machine,” Annals of Statistics, 2001.
15. L. Prokhorenkova et al., “CatBoost: Unbiased boosting with categorical features,” NeurIPS, 2018.
16. T. Chen and C. Guestrin, “XGBoost: A scalable tree boosting system,” KDD, 2016.
17. G. Ke et al., “LightGBM: A highly efficient gradient boosting decision tree,” NeurIPS, 2017.
18. P. Kar, H. Narasimhan, and P. Jain, “Surrogate functions for maximizing precision at the top,” ICML, 2015.
19. A. Niculescu-Mizil and R. Caruana, “Predicting good probabilities with supervised learning,” ICML, 2005.
20. M. Hardt, E. Price, and N. Srebro, “Equality of opportunity in supervised learning,” NeurIPS, 2016.
21. A. Rajkomar et al., “Ensuring fairness in machine learning to advance health equity,” Annals of Internal Medicine, 2018.
22. S. Lundberg and S.-I. Lee, “A unified approach to interpreting model predictions,” NeurIPS, 2017.
23. I. E. Kumar et al., “Problems with Shapley-value-based explanations as feature importance measures,” ICML, 2020.
24. J. Amann et al., “Explainability for artificial intelligence in healthcare,” BMC Medical Informatics and Decision Making, 2020.
25. WHO, *Ethics and Governance of Artificial Intelligence for Health*, 2021.
26. NIST, *Artificial Intelligence Risk Management Framework (AI RMF 1.0)*, 2023.
27. J. Gama et al., “A survey on concept drift adaptation,” ACM Computing Surveys, 2014.
28. B. Efron and R. Tibshirani, *An Introduction to the Bootstrap*, 1993.
29. E. B. Wilson, “Probable inference, the law of succession, and statistical inference,” JASA, 1927.
30. C. J. Kelly et al., “Key challenges for delivering clinical impact with artificial intelligence,” BMC Medicine, 2019.
31. CatBoost official GPU training documentation.
32. XGBoost official CUDA/GPU documentation.

Additional research directions discussed later:

33. Narasimhan & Agarwal, structural optimization approaches for partial AUC / low-FPR ranking.
34. Later pAUC hard-negative optimization using DRO/CVaR-style formulations (discussed conceptually; verify exact citation before final report if used).
35. TabR, retrieval-augmented tabular deep learning, ICLR 2024.
36. ModernNCA, modern neighborhood/component analysis for tabular data (verify exact final publication citation before report if used).
37. TabM, parameter-efficient ensemble MLP for tabular data, ICLR 2025.

Only references actually used in final argument should appear in the final report bibliography.
