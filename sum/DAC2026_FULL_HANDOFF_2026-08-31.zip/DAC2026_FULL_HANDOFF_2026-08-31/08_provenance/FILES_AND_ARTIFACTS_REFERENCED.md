# Files / Artifacts Referenced During the Work

These are **not included** in this handoff ZIP by user request. This list exists so a future chat knows what artifacts existed.

## Official / dataset archives

- `dac-its-2026.zip` — original competition data archive.
- `preliminary-round-dac-2026.zip` / `new-dac-2026.zip` — reset competition archive; compared byte-identical to original.
- Official `train.csv`, `test.csv`, `sample_submission.csv`.

## Prior-year references

- `Answer Sheets_sayonarasrama [-1].pdf` — DAC 2025 winning answer sheet; structural/report reference only.
- `InfoMagangDong.zip` — prior runner-up materials; notebook inside appeared to be a different Objective Quest task, useful only as code/presentation reference.

## Project handoff/reference

- `DAC2026_COMPLETE_CHAT_HANDOFF_2026-08-30.md` — comprehensive V1/V2 handoff created before V3–V5.
- Technical Meeting PDF (`PPT TM DAC 2026_...pdf`) — contained report/leaderboard scoring weights and submission instructions.

## Notebook versions that existed

- V1: `DAC2026_Ultimate_Baseline_T4x2.ipynb`
- V2: `DAC2026_V2_Ultimate.ipynb`
- V3: `DAC2026_V3_RankFirst_T4x2.ipynb`
- V4: `DAC2026_V4_OfficialOnly_NR5_T4x2.ipynb`
- V5: `DAC2026_V5_RepairedBoundary_T4x2.ipynb`

## Result/submission artifacts that existed

Separate V1/V2/V3/V4/V5 result bundles and submission CSVs were inspected during analysis. They are intentionally omitted here.

## Helper ground-truth files

- `ground_truth.csv`: test IDs, blank labels only.
- `ground_truth_train_reference.csv`: train IDs and known train labels.

These were analysis-only helpers and were deliberately excluded from competition notebooks.
