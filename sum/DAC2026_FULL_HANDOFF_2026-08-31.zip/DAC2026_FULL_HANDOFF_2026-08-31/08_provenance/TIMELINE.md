# Project Timeline

## V1 phase

- Built comprehensive competition notebook with EDA, grouped CV, model ladder, calibration, fairness, explainability, robustness, and submission.
- Executed on Kaggle T4 x2.
- Public LB 0.95833.
- Post-run forensic audit discovered source-order tie artifact and deployment/calibration issues.

## V2 phase

- Rebuilt pipeline around corrected evaluation contract.
- First full run failed late due experiment-registry eligibility `NaN` bug.
- Root cause fixed with explicit registry contracts/preflight validation.
- Successful rerun on T4 x2.
- Selected CatBoost seed 2127, OOF NR 0.970529.
- Later Public LB reported 0.96333.

## V3 phase

- Shifted to rank-first top-5 objective.
- Added diverse cross-fitted stacker and supervised high-risk refiner.
- Final OOF NR 0.977522, TP 7,828.
- Public LB 0.97166, best known leaderboard result.

## Competition reset

- Organizers banned external data, reset leaderboard, required reproducibility, increased daily submissions to 5, and released expanded data dictionary.
- New official CSVs compared with old and found byte-identical.

## V4 phase

- Tried conservative official-only fixed consensus and multi-scale empirical-risk direct reranking.
- Boundary reranking consistently hurt OOF; final fell back to global Cat mean.
- OOF 0.97340, Public 0.96000.
- Same V4 submission also scored 0.96000 on old competition.

## V5 phase

- Restored V3 supervised architecture, added V4 EB evidence as features, and added repeated meta/refiner CV plus complete fold-bagged test inference.
- OOF improved to 0.981019, 7,856 TP, 10/10 fold wins.
- Reset Public LB only 0.96666.
- This reversed the assumption that deployment-aligned bagging must beat V3's full-data boundary refit.

## Current phase

- Freeze V3 branch.
- Design V6 to isolate final refiner deployment strategy only.
- Prepare report in parallel.
