# What Happened After the 30-August V1/V2 Handoff

The earlier handoff stopped after V2. The major additions since then are:

1. **V2 leaderboard result supplied later:** 0.96333.
2. **V3 developed and executed:** rank-first diverse base stack + supervised boundary CatBoost; OOF 0.977522, Public 0.97166.
3. **V3 forensics:** top-K portfolio changed materially versus V2; supervised boundary stage produced real OOF gain; final test used one full-data refiner.
4. **Organizer reset:** external data banned, leaderboard reset, reproducibility hard requirement, 5 submissions/day, expanded data dictionary.
5. **Old/new CSV comparison:** byte-identical, including label-blocked row order.
6. **V4 developed:** conservative fixed rank consensus + multi-scale local empirical-risk direct reranking. OOF 0.97340, Public 0.96000; direct local risk hurt.
7. **V5 developed:** V3 supervised architecture restored; V4 EB features used as evidence; repeated meta/refiner validation and 10-component fold-bagged inference. OOF 0.981019, Public 0.96666.
8. **Key reversal:** cleaner/repeated V5 validation did not beat V3 hidden public, so V3's full-data final boundary refit became a research target rather than an obvious flaw.
9. **Current plan:** V6 isolates deployment/refiner inference only; no broad architecture change.
10. **Integrity decision:** rumored positional 50/50 perfect-score trick is not to be used; focus on reproducible feature-based model and strong paper.
