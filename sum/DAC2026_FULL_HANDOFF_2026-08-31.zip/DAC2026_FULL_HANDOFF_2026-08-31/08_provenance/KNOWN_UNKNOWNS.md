# Known, Inferred, and Unknown

## Known from executed evidence

- Dataset shapes/counts and label storage order.
- Old/new official CSVs are byte-identical.
- V1–V5 OOF results listed in this package.
- User-reported leaderboard scores listed in this package.
- V4 direct local-risk reranking hurt OOF.
- V5 repeated boundary refiner won 10/10 train-held-out views yet did not beat V3 public score.
- Location transport stress is much worse than in-distribution CV.

## Strong interpretations

- CatBoost is the strongest base family.
- V3 supervised boundary learning is the most successful architecture change.
- Empirical-risk statistics are better used as features than direct ranking rules.
- Small OOF gains are not enough to justify large test portfolio churn.
- The key unresolved issue is deployment/inference transfer at the high-risk boundary.

## Plausible but not proven

- V3's full-data final refiner may outperform V5 bagging because it sees all rare hard negatives.
- Public score granularity corresponds to ~600 audit slots.
- Some location signal may reflect provider/investigation/data-generation processes rather than causal fraud propensity.

## Unknown

- Hidden test labels.
- Exact organizer tie-breaking implementation when probabilities are exactly tied.
- Whether V3 has been submitted to the reset leaderboard after the reset.
- Private leaderboard performance for any version.
- Hidden-label prevalence and subgroup outcomes.
- True operational fraud prevalence.
- Whether one full-data refiner will remain best on private 70% labels.
- Provider/member/time identities not present in the data.
- Causal interpretation of feature associations.
