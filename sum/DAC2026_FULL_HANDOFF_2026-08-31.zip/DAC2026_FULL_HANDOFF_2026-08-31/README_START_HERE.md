# DAC 2026 — Full Conversation Handoff

**Cut-off:** 31 August 2026, Asia/Jakarta  
**Purpose:** continue the DAC 2026 work in a fresh chat without restarting research, repeating failed experiments, confusing old-vs-reset Kaggle evidence, or losing the reasoning behind V1–V5.

This package intentionally contains **no notebooks, trained predictions, result ZIPs, or submission CSVs**. It contains only the state of knowledge, experiment history, findings, failures, rules, research synthesis, report strategy, and exact next steps.

## Read these first

1. `00_current_state/CURRENT_STATUS.md`
2. `03_experiment_history/CROSS_VERSION_COMPARISON.md`
3. `04_failure_analysis/WHAT_FAILED_AND_WHY.md`
4. `07_next_model/V6_BLUEPRINT.md`
5. `00_current_state/NEXT_CHAT_PROMPT.md`

## One-paragraph state

The official train/test/sample files in the reset Kaggle competition were verified to be byte-identical to the original files. The train file still has the severe storage-order artifact where all positive labels precede all negative labels, so row position and source-order tie breaking must never be predictive. The original leaderboard was reset after organizers banned external data and required reproducibility. V3 remains the best **observed leaderboard model** at 0.97166 from the earlier leaderboard, while V5 is the best **offline OOF model** at 0.981019 but scored only 0.96666 on the reset leaderboard. V4 scored 0.96000. This means higher grouped-OOF NR@5 is not transferring monotonically to hidden ranking. The current next step is **not another architecture expansion**. Freeze V3 as champion architecture and run a controlled V6 study focused on its final deployment/refiner inference recipe, especially testing whether full-data hard-negative training is the reason V3 transfers better than the cleaner fold-bagged V5.

## Integrity boundary

The reset rules prohibit external data, external row matching, hidden-label reconstruction, leaked labels, manually encoded leaderboard information, cross-team circumvention, and use of claim ID as a feature. Papers and public methodology references are fine as theory, but prediction inputs must come only from the official competition data. A rumored 50/50 positional trick is documented here only as a **leakage/integrity finding**, not as an allowed model strategy.
